document.addEventListener("DOMContentLoaded", function() {
    const sections = document.querySelectorAll(".section");
    const scrollButtons = document.querySelectorAll(".scroll-btn");

    scrollButtons.forEach(function(button) {
        button.addEventListener("click", function() {
            const targetSection = button.getAttribute("data-section");
            const targetElement = document.querySelector("." + targetSection);
            scrollToSection(targetElement);
        });
    });

    function scrollToSection(element) {
        element.scrollIntoView({ behavior: "smooth" });
    }
});
