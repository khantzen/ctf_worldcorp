Worldcorp Landing Page
---

Simple html landing page for worldworp landing page !

You'll find all the data about worldcorp on it !

This one is used until we figure a way to have a dynamic interface !!!! 

---

Deployment,

SSH to the machine, copy paste from preproduction to production directory !
